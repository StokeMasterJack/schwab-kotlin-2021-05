## Declaring Variables


val y = 5   //final - can not be changed
java equiv:
    public final int y = 5

var x = 3  //not-final
    public  int y = 5


const val y = 5   //compile time constant - can not be changed (simple types)